package com.example.projecttickets.Activity;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.projecttickets.Model.Trains;
import com.example.projecttickets.R;
import com.example.projecttickets.databinding.ActivityTicketDetailBinding;

public class TicketDetailActivity extends BaseActivity {
    private ActivityTicketDetailBinding binding;
    private Trains trains;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityTicketDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        setVariable();

    }

    private void setVariable() {
        binding.backBtn.setOnClickListener(v -> finish());
        binding.fromTxt.setText(trains.getFromShort());
        binding.fromSmallTxt.setText(trains.getFrom());
        binding.toTxt.setText(trains.getTo());
        binding.toShortTxt.setText(trains.getToShort());
        binding.toSmallTxt.setText(trains.getTo());
        binding.dateTxt.setText(trains.getDate());
        binding.timeTxt.setText(trains.getTime());
        binding.arrivalTxt.setText(trains.getArriveTime());
        binding.classTxt.setText(trains.getClassSeat());
        binding.priceTxt.setText(trains.getPrice() + "BYN");
        binding.traincomp.setText(trains.getTrainName());
        binding.seatsTxt.setText(trains.getPassenger());

        Glide.with(TicketDetailActivity.this)
                .load(trains.getTrainLogo())
                .into(binding.logo);
    }

    private void getIntentExtra() {
        trains= (Trains) getIntent().getSerializableExtra("trains");
    }
}