package com.example.projecttickets.Model;

public class Locations {
    private int Id;
    private String Name;

    public Locations() {
    }

    @Override
    public String toString() {
        return  Name;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }
}
