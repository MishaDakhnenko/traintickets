package com.example.projecttickets.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.projecttickets.Activity.SearchActivity;
import com.example.projecttickets.Activity.SeatListActivity;
import com.example.projecttickets.Model.Trains;
import com.example.projecttickets.databinding.ViewholderTrainsBinding;

import java.util.ArrayList;
import java.util.HashMap;

public class TrainsAdapter extends RecyclerView.Adapter<TrainsAdapter.Viewholder> {
    private final ArrayList<Trains> train;
    private Context context;

    public TrainsAdapter(ArrayList<Trains> train) {
        this.train = train;
    }

    @NonNull
    @Override
    public TrainsAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context=parent.getContext();
        ViewholderTrainsBinding binding=ViewholderTrainsBinding.inflate(LayoutInflater.from(context),parent,false);
        return new Viewholder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TrainsAdapter.Viewholder holder, int position) {
        Trains trains = train.get(position);
        Glide.with(context)
                .load(trains.getTrainLogo())
                .into(holder.binding.logo);

        holder.binding.fromTxt.setText(trains.getFrom());
        holder.binding.fromShortTxt.setText(trains.getFromShort());
        holder.binding.toTxt.setText(trains.getTo());
        holder.binding.toShortTxt.setText(trains.getToShort());
        holder.binding.arrivalTxt.setText(trains.getArriveTime());
        holder.binding.classTxt.setText(trains.getClassSeat());
        holder.binding.priceTxt.setText(trains.getPrice()+"BYN");


        holder.itemView.setOnClickListener(v -> {
            Intent intent=new Intent(context, SeatListActivity.class);
            intent.putExtra("trains",trains);
            context.startActivity(intent);
        });


    }

    @Override
    public int getItemCount() {
        return train.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        private final ViewholderTrainsBinding binding;
        public Viewholder(ViewholderTrainsBinding binding) {
            super(binding.getRoot());
            this.binding=binding;
        }
    }
}
